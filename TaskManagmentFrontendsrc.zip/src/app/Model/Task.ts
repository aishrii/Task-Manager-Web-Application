export class Task{
    
    id:number;
    taskName:string;
    description:string;
    remark:string='no remark as of yet';
    status:string='Pending';
    donePercentage:number=0;
    startDate:Date;
    endDate:Date;
}