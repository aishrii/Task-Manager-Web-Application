import { Component } from '@angular/core';
import {  HostBinding } from '@angular/core';
import { Task } from '../Model/Task';
import { User } from '../Model/User';
import { HttpClient } from '@angular/common/http';
import { log } from 'console';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrl: './user-dashboard.component.css'
})
export class UserDashboardComponent {
  @HostBinding('attr.ngSkipHydration') skipHydration = false; // Or use directive's property
  tasks: Task[] = []; // Array to hold tasks
  url:"http://localhost:8080/";
  // newTask: Task
  newTask: Task = new Task()
  // newTask: Task = { // Empty object for new task creation
  //   id: 0,
  //   taskName: '',
  //   description: '',
  //   remark: 'no remark as of yet',
  //   status: 'Pending', // Consider using an enum for predefined statuses
  //   donePercentage: 0,
  //   startDate: new Date(),
  //   endDate: new Date()
  // };
  currentUser: User; // Store the current user

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    // Fetch tasks or initialize from a service (implementation omitted)
    this.currentUser = { // Example user data (replace with actual logic)
      id: 1,
      userName: 'Task Management',
      email: 'john.doe@example.com',
      password: '' // Consider not storing password in plain text
    };
  }
  LoadTask(){
    this.http.get("http://localhost:8080/loadTaskFromDB").subscribe(
      (data:any)=>{
        this.tasks=data;
        console.log(data);
      }
    )
  }
  addTask(): void {
    this.http.post("http://localhost:8080/addTask",this.newTask).subscribe(
      (data:any)=>{
        if(data==true)
          window.alert("task saved successfuly")
        else
        window.alert("error in saving Task")
      }
    )
    this.tasks.push({ ...this.newTask }); // Create a copy to avoid mutation
    this.newTask = { ...this.newTask, id: 0, taskName: '', description: '' }; // Reset newTask object
    // Implement logic to persist the new task to a service (implementation omitted)
  
  
  }

  edittTask: Task = new Task()
  showForm:boolean = false
  currentTask
  toggleEditForm(i:number){
   
    this.currentTask=this.tasks[i];

    this.http.get("http://localhost:8080/getTask"+this.currentTask.taskName).subscribe(
      (data:any)=>{
        console.log(data)
        this.editTask=data
          this.showForm = !this.showForm;
      }
    )
    
  }
  editTask(){

  }
  editTask1(): void {
    //this.tasks[i].taskName
    console.log(this.newTask);
    this.http.post("http://localhost:8080/editTask"+this.currentTask.taskName,this.edittTask).subscribe(
      (data:any) => {
        if(data == true)
          {
            window.alert("Task updated Successfully..")
          }
          else
          window.alert("Exception on server...")
      }
    )
    }

  deleteTask(taskId: number): void {
    const taskIndex = this.tasks.findIndex(t => t.id === taskId);
    if (taskIndex !== -1) {
      this.tasks.splice(taskIndex, 1);
      // Implement logic to delete the task from a service (implementation omitted)
    }
     
    
    // this.http.get("http://localhost:8080/deleteTask"+this.tasks[taskId].taskName).subscribe(
    //     (data:any) => {
    //       if(data==true)
    //         window.alert("Task deleted succefully...");
    //       else
    //       window.alert("Exception on server...")
    //     }
    //   )
  }

  showFullDescription(task: Task): void {
    // Implement logic to display a modal or popup with the full description (implementation omitted)
    console.log('Full Description for task:', task.description); // Placeholder for now
  }
}
