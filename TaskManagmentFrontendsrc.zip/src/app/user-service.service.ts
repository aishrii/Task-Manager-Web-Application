import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './Model/User';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private http:HttpClient) { }
  add(user:User):Observable<any>{
    return this.http.post<any>(`http://localhost:8080/register`,user);
  }


}
